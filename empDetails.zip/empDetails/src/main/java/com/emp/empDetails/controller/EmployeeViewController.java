package com.emp.empDetails.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.emp.empDetails.service.EmployeeService;

@Controller
public class EmployeeViewController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/")
    public String showEmployeeForm() {
        return "index"; // Return the name of the Thymeleaf template
    }

    @GetMapping("/employeeListView") // Change to avoid conflict
    public String showEmployeeList(Model model) {
        model.addAttribute("employees", employeeService.getAllEmployees());
        return "employeeList";
    }
}
