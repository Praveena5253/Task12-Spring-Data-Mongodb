package com.emp.empDetails.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.emp.empDetails.entity.Employee;

@Repository
public interface EmployeeRepository extends MongoRepository<Employee, String> {
}

